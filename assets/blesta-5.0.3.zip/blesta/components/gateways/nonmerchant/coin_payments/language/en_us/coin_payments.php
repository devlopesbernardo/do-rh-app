<?php
$lang['CoinPayments.name'] = 'CoinPayments.net';
$lang['CoinPayments.description'] = 'A checkout system for cryptocurrencies such as Bitcoin and Litecoin with low fees';

$lang['CoinPayments.merchant_id'] = 'CoinPayments Merchant ID';
$lang['CoinPayments.ipn_secret'] = 'IPN Secret';
$lang['CoinPayments.buildprocess.submit'] = 'Pay with CoinPayments';
